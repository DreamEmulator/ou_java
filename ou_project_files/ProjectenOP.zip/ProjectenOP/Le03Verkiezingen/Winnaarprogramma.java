import java.util.ArrayList;
import verkiezingen.Kandidaat;
import verkiezingen.Partij;
import verkiezingen.Stemmachine;

public class Winnaarprogramma {
  public static void main(String[] args) {
  }
}
