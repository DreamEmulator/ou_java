import verkiezingen.Stemmachine;

public class Verkiezingsprogramma {
  public static void main(String[] args) {

    // type na deze regel de opdrachten in

  }
}