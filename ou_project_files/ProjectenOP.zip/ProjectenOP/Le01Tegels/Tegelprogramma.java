import tegels.Tegel;

public class Tegelprogramma {
  public static void main(String[] args) {

    // type na deze regel de opdrachten in
    
  }
}