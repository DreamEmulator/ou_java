/*
 * Een superkort Javaprogramma
 */
public class HalloWereld {

  public static void main(String[] args) {
    System.out.println("Hallo, wereld!");
  }

}
